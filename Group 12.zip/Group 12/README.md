# Task Organizer

A simple and effective PHP web application for managing your daily tasks. Features a clean interface and connects to MySQL for data storage.

## Key Features

- Create tasks with title, description, priority, and due date
- View tasks in an organized list
- Edit and update existing tasks
- Mark tasks as completed
- Delete tasks when no longer needed
- Works on both desktop and mobile devices

## System Requirements

- PHP 7.4 or higher
- MySQL database
- Web server (like XAMPP)
- Modern web browser

## Getting Started

1. Place the project files in your web server's document root
2. Start your web server and MySQL
3. Create a database named `task_organizer`
4. Import the `database.sql` file into your database
5. Open the application in your browser

## Database Setup

Update the database connection details in `config/database.php` if needed:

- Default host: localhost
- Default database: task_organizer
- Default username: root
- Default password: (leave empty for XAMPP)

## How to Use

- **Add Task**: Fill the form and click "Add Task"
- **Edit Task**: Click the edit button on any task
- **Complete Task**: Click the checkmark to mark as done
- **Delete Task**: Click the trash icon to remove

## Project Files

```
├── index.php           # Main page
├── add_task_ajax.php   # Add task handler
├── edit_task.php       # Edit task page
├── delete_task.php     # Delete handler
├── mark_complete.php   # Complete task handler
├── database.sql        # Database setup
├── config/
│   └── database.php    # Database config
└── assets/
    ├── css/style.css   # Styles
    └── js/script.js    # JavaScript
```

## Customization

Modify `assets/css/style.css` to change colors and layout. The main styles are defined at the top of the file.

## License

Free to use for personal projects.